import Link from "next/link";
import { Activity, ArrowRight, CalendarDays, CheckCircle2, ClipboardList, FileHeart, HeartPulse, LockKeyhole, ShieldCheck, Stethoscope, Users, Clock3 } from "lucide-react";

const features = [
  { icon: FileHeart, title: "Unified medical records", text: "Keep consultations, prescriptions, lab reports, vaccinations and allergies in one organized place." },
  { icon: Clock3, title: "A clear care timeline", text: "See visits, tests and treatment history chronologically, so important details are easier to find." },
  { icon: ShieldCheck, title: "Consent-led sharing", text: "Choose which provider can access your records, for what purpose and until when. Revoke access when needed." },
  { icon: CalendarDays, title: "Connected appointments", text: "Keep appointment requests, upcoming visits and care follow-ups together." },
];
export default function Home() {
  return <main className="min-h-screen overflow-hidden">
    <header className="mx-auto flex max-w-7xl items-center justify-between px-5 py-5 md:px-8">
      <Link href="/" className="flex items-center gap-3">
        <span className="grid h-11 w-11 place-items-center rounded-2xl bg-[#104C39] text-white"><HeartPulse size={24}/></span>
        <span><strong className="block text-xl tracking-tight text-[#104C39]">CareBridge</strong><small className="text-xs text-[#6D8177]">Your Health, Connected</small></span>
      </Link>
      <nav className="hidden items-center gap-7 text-sm text-[#52675c] md:flex"><a href="#features">Features</a><a href="#privacy">Privacy first</a><a href="#portals">For care teams</a></nav>
      <div className="flex gap-2"><Link className="btn-secondary" href="/login">Log in</Link><Link className="btn-primary" href="/register">Get started <ArrowRight size={16}/></Link></div>
    </header>
    <section className="mx-auto grid max-w-7xl items-center gap-12 px-5 pb-20 pt-12 md:grid-cols-[1.05fr_.95fr] md:px-8 md:pb-28 md:pt-20">
      <div className="fade-in">
        <div className="mb-6 inline-flex items-center gap-2 rounded-full border border-[#cfe5d4] bg-white px-3 py-2 text-xs font-semibold text-[#104C39]"><span className="h-2 w-2 rounded-full bg-[#4e9d72]"/> Healthcare continuity, built around you</div>
        <h1 className="max-w-2xl text-5xl font-semibold leading-[1.08] tracking-[-.055em] text-[#104C39] md:text-7xl">Your health story, <span className="text-[#67947a]">all in one place.</span></h1>
        <p className="mt-6 max-w-xl text-lg leading-8 text-[#60766a]">Bring your medical history together and share selected information with the healthcare professionals you trust — on your terms.</p>
        <div className="mt-8 flex flex-wrap gap-3"><Link href="/register" className="btn-primary">Create your account <ArrowRight size={17}/></Link><a href="#features" className="btn-secondary">Explore the platform</a></div>
        <div className="mt-9 flex flex-wrap gap-x-6 gap-y-3 text-sm text-[#60766a]"><span className="flex items-center gap-2"><CheckCircle2 size={16} className="text-[#3e8860]"/> Patient-controlled consent</span><span className="flex items-center gap-2"><LockKeyhole size={16} className="text-[#3e8860]"/> Private by design</span></div>
      </div>
      <div className="relative fade-in">
        <div className="absolute -right-6 -top-8 h-48 w-48 rounded-full bg-[#dcefe2] blur-3xl"/>
        <div className="surface relative p-5 md:p-7">
          <div className="flex items-center justify-between"><div><p className="text-sm text-[#6D8177]">Patient overview</p><h2 className="mt-1 text-2xl font-semibold text-[#104C39]">Your health, organized</h2></div><span className="rounded-xl bg-[#e8f4eb] p-3 text-[#104C39]"><Activity size={22}/></span></div>
          <div className="mt-6 grid grid-cols-2 gap-3">
            {[["Medical records","12","FileHeart"],["Upcoming visits","2","CalendarDays"],["Active prescriptions","3","ClipboardList"],["Care providers","4","Stethoscope"]].map(([label,value,icon])=><div key={label} className="rounded-2xl border border-[#e7eee8] bg-[#fbfdfb] p-4"><p className="text-xs text-[#718278]">{label}</p><p className="mt-2 text-3xl font-semibold text-[#104C39]">{value}</p><div className="mt-3 h-1.5 rounded-full bg-[#e4eee6]"><div className="h-1.5 w-2/3 rounded-full bg-[#8dbb9b]"/></div></div>)}
          </div>
          <div className="mt-5 rounded-2xl bg-[#f1f7f2] p-4"><div className="flex items-center gap-3"><span className="rounded-xl bg-white p-2.5 text-[#104C39]"><ShieldCheck size={20}/></span><div className="flex-1"><p className="font-semibold text-[#104C39]">You’re in control</p><p className="mt-1 text-xs leading-5 text-[#718278]">Review who can access your records, with clear expiry and revocation controls.</p></div><ArrowRight size={18} className="text-[#5d8a6b]"/></div></div>
          <p className="mt-4 text-center text-[11px] text-[#8a9b91]">Illustrative interface preview · not real patient data</p>
        </div>
      </div>
    </section>
    <section id="features" className="border-y border-[#e6eee7] bg-white/70 py-20">
      <div className="mx-auto max-w-7xl px-5 md:px-8"><div className="max-w-2xl"><p className="text-sm font-bold uppercase tracking-[.18em] text-[#5e9270]">One connected journey</p><h2 className="mt-3 text-3xl font-semibold tracking-tight text-[#104C39] md:text-4xl">Less searching. More continuity.</h2><p className="mt-4 leading-7 text-[#65796e]">The essentials for patients and care teams, designed to make health information easier to manage and safer to share.</p></div>
      <div className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">{features.map(({icon:Icon,title,text})=><article key={title} className="surface p-6 transition hover:-translate-y-1 hover:shadow-md"><span className="grid h-12 w-12 place-items-center rounded-2xl bg-[#e6f3e9] text-[#104C39]"><Icon size={22}/></span><h3 className="mt-5 text-lg font-semibold text-[#104C39]">{title}</h3><p className="mt-3 text-sm leading-6 text-[#718278]">{text}</p></article>)}</div></div>
    </section>
    <section id="privacy" className="mx-auto grid max-w-7xl gap-10 px-5 py-20 md:grid-cols-2 md:items-center md:px-8">
      <div><p className="text-sm font-bold uppercase tracking-[.18em] text-[#5e9270]">Privacy is foundational</p><h2 className="mt-3 text-3xl font-semibold tracking-tight text-[#104C39] md:text-4xl">Your records aren’t everyone’s records.</h2><p className="mt-5 leading-7 text-[#65796e]">CareBridge is designed around server-side authorization, time-limited consent and auditable access. A role alone should never unlock someone else’s medical history.</p><div className="mt-6 space-y-4">{["Selected records and clear sharing purpose","Expiry and revocation enforced by the backend","Audit trail for access and permission changes"].map(t=><p key={t} className="flex items-start gap-3 text-sm text-[#405e4e]"><CheckCircle2 size={18} className="mt-0.5 shrink-0 text-[#4b9466]"/>{t}</p>)}</div></div>
      <div className="surface bg-[#edf6ef] p-7 md:p-9"><div className="grid h-14 w-14 place-items-center rounded-2xl bg-[#104C39] text-white"><LockKeyhole size={27}/></div><h3 className="mt-5 text-2xl font-semibold text-[#104C39]">Consent that means something</h3><p className="mt-3 leading-7 text-[#60766a]">Grant access for a specific care purpose, choose a time limit and revoke it when you need to. Protected API routes check the current user and consent on each request.</p><div className="mt-6 rounded-xl border border-[#d5e7d9] bg-white p-4 text-sm text-[#52675c]"><span className="font-semibold text-[#104C39]">Security note</span><br/>This starter requires deployment secrets and a security review before handling real patient information.</div></div>
    </section>
    <section id="portals" className="bg-[#104C39] py-16 text-white"><div className="mx-auto max-w-7xl px-5 md:px-8"><div className="max-w-2xl"><p className="text-sm font-bold uppercase tracking-[.18em] text-[#b8dfc3]">Built for the whole care team</p><h2 className="mt-3 text-3xl font-semibold md:text-4xl">One platform. Role-aware workflows.</h2><p className="mt-4 leading-7 text-[#d3e5d8]">Separate access paths for patients, doctors, hospitals and administrators — each with only the permissions they need.</p></div><div className="mt-8 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">{[{icon:HeartPulse,title:"Patients",text:"Records, timeline, consent and appointments"},{icon:Stethoscope,title:"Doctors",text:"Verified access and consultation workflow"},{icon:Users,title:"Hospitals",text:"Provider coordination and authorized care"},{icon:ShieldCheck,title:"Administrators",text:"Verification, account status and audit logs"}].map(({icon:Icon,title,text})=><div key={title} className="rounded-2xl border border-white/15 bg-white/[.07] p-5"><Icon size={23} className="text-[#b8dfc3]"/><h3 className="mt-4 font-semibold">{title}</h3><p className="mt-2 text-sm leading-6 text-[#d3e5d8]">{text}</p></div>)}</div></div></section>
    <footer className="mx-auto flex max-w-7xl flex-col gap-3 px-5 py-8 text-sm text-[#718278] md:flex-row md:items-center md:justify-between md:px-8"><p>© {new Date().getFullYear()} CareBridge · Your Health, Connected</p><p>Privacy-first by design · Demo data only</p></footer>
  </main>;
}