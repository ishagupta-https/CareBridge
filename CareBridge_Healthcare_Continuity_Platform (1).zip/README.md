# CareBridge — Healthcare Continuity Platform

A responsive React + Vite prototype for the Buildsaur / Indigo Tech Fest Software Track 2 problem statement.

## Features in this prototype
- Patient dashboard with summary cards and recent records
- Medical records list with search
- Care timeline
- Add medical record modal
- Provider directory
- Patient-controlled sharing and revoke-access UI
- Demo sign-in screen
- Responsive desktop, tablet, and mobile layouts

## Run locally
1. Install Node.js (LTS).
2. Extract this ZIP and open the folder in VS Code.
3. Open Terminal in VS Code and run:
   ```bash
   npm install
   npm run dev
   ```
4. Open the local URL shown by Vite (usually `http://localhost:5173`).

## Build
```bash
npm run build
```
The production output is created in `dist/`.

## Important security note
This is a front-end demo with fictional sample data. Sign-in and sharing are simulated in browser state only. It is **not** a production healthcare system and does not securely store or transmit real medical records. Before real use, add a secure backend, database encryption, verified authentication, role-based authorization, consent and audit logs, secure document storage, backups, and applicable privacy/legal compliance. Do not enter real patient information in this prototype.

## Suggested next-stage architecture
- Frontend: React + Vite (or Next.js)
- Backend: Node.js/Express or Next.js API routes
- Database: PostgreSQL
- Authentication: verified identity provider, secure sessions and MFA
- Records: structured medical history and secure document storage
- Interoperability: evaluate HL7 FHIR resources for Patient, Encounter, Observation, MedicationRequest, DiagnosticReport and Consent
