# CareBridge pre-production security checklist

- [ ] Managed PostgreSQL provisioned; TLS enforced; least-privilege application DB user
- [ ] `DATABASE_URL` and `SESSION_SECRET` configured as encrypted environment variables
- [ ] Initial admin created via controlled one-time process; no admin self-registration
- [ ] Provider identity/registration verified before activating doctor/hospital account
- [ ] Rate limits and brute-force protection for auth and consent routes
- [ ] Origin/CSRF controls reviewed for cookie-authenticated mutations
- [ ] Private object storage bucket; no public access; encryption at rest
- [ ] File validation by extension, MIME, magic bytes, size, and malware scan
- [ ] Short-lived download authorization and signed URLs; audit every document access
- [ ] Consent checks validate patient, provider, active status, expiry, revocation, purpose, selected IDs and categories
- [ ] All appointment, encounter, diagnosis, medication and prescription mutations enforce role and relationship checks
- [ ] Tests for IDOR, expired consent, revoked consent, role escalation, session tampering, and audit integrity
- [ ] Backups, restore test, monitoring, alerting and incident response documented
- [ ] Privacy notice, retention/deletion policy and applicable legal review completed
- [ ] No real patient information used in demo or preview environments
