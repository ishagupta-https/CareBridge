import type { Metadata } from "next";
import "./globals.css";
export const metadata: Metadata = {
  title: "CareBridge — Your Health, Connected",
  description: "A secure, patient-consent-first healthcare continuity platform.",
};
export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body>{children}</body></html>;
}