import { NextRequest, NextResponse } from "next/server";
import { and, desc, eq, gt, isNull, or } from "drizzle-orm";
import { db } from "@/lib/db";
import { consents, medicalDocuments } from "@/lib/schema";
import { currentUser } from "@/lib/session";
import { audit } from "@/lib/audit";

export async function GET(req: NextRequest) {
  const user = await currentUser();
  if (!user) return NextResponse.json({ error: "Unauthenticated" }, { status: 401 });
  const patientId = req.nextUrl.searchParams.get("patientId") || (user.role === "patient" ? user.id : "");
  if (!patientId) return NextResponse.json({ error: "A patient ID is required." }, { status: 400 });
  if (user.role === "patient" && patientId !== user.id) return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  if (user.role !== "patient" && user.role !== "admin") {
    const now = new Date();
    const active = await db.select({ id: consents.id }).from(consents).where(and(
      eq(consents.patientId, patientId), eq(consents.providerId, user.id),
      isNull(consents.revokedAt), gt(consents.expiresAt, now)
    )).limit(1);
    if (!active.length) {
      await audit({ actorId: user.id, patientId, action: "read_records", resourceType: "medical_documents", outcome: "denied", ip: req.headers.get("x-forwarded-for") });
      return NextResponse.json({ error: "Patient consent is required or has expired." }, { status: 403 });
    }
  }
  const rows = await db.select({
    id: medicalDocuments.id, type: medicalDocuments.type, title: medicalDocuments.title,
    mimeType: medicalDocuments.mimeType, sizeBytes: medicalDocuments.sizeBytes, createdAt: medicalDocuments.createdAt
  }).from(medicalDocuments).where(eq(medicalDocuments.patientId, patientId)).orderBy(desc(medicalDocuments.createdAt));
  await audit({ actorId: user.id, patientId, action: "read_records", resourceType: "medical_documents", outcome: "allowed", ip: req.headers.get("x-forwarded-for"), metadata: { count: rows.length } });
  return NextResponse.json({ records: rows });
}