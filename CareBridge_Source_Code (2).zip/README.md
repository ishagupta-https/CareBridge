# CareBridge — Your Health, Connected

A Next.js + TypeScript healthcare-continuity platform scaffold using PostgreSQL/Drizzle, server-side signed sessions, role-aware pages, consent endpoints, and audit logging. Demo content is illustrative only; no real patient records are included.

## Stack
- Next.js App Router + TypeScript
- Tailwind CSS v4
- PostgreSQL + Drizzle ORM
- bcrypt password hashing and signed HttpOnly session cookies
- Zod request validation
- Private document metadata schema (private object storage adapter still needs provider setup)

## Run locally
1. Install Node.js 20+ and PostgreSQL.
2. Copy `.env.example` to `.env.local`.
3. Set `DATABASE_URL` to your PostgreSQL connection string.
4. Set `SESSION_SECRET` to a cryptographically random value at least 32 characters long.
5. Run:
   ```bash
   npm install
   npm run db:push
   npm run dev
   ```
6. Open http://localhost:3000.

## Account activation
New accounts intentionally start in `pending` state. Login is blocked until an administrator-approved workflow sets `users.status = 'active'`. Provider profiles also require verification. Admin self-registration is disabled. Bootstrap the first admin using a secure, one-time, out-of-band database operation after deployment; never hardcode admin credentials in source code.

## Implemented API routes
- `POST /api/auth/register`
- `POST /api/auth/login`
- `POST /api/auth/logout`
- `GET /api/me`
- `GET /api/records?patientId=...` (patient self-access; providers need active consent; admin has audit-only intent but must not be used to expose clinical data)
- `GET /api/consents`
- `POST /api/consents` (patient-only grant; provider must be active; expiry max 90 days)
- `POST /api/consents/:id/revoke`
- `GET /api/admin/audit` (admin only)

## Important limitations before production
This is a working project foundation, not a certified clinical system. Do **not** upload or enter real medical information until a security and privacy review is completed.

Before handling real health data:
- Implement and test document-level consent enforcement on every record endpoint. The included list endpoint checks active patient/provider consent, but production code must also enforce each consent's selected document IDs/categories and purpose.
- Add secure private object storage (S3-compatible private bucket), server-side file type/content inspection, strict size limits, malware scanning, signed short-lived download URLs, and no public document URLs.
- Add rate limiting, CSRF/origin checks, account recovery, email verification, MFA for providers/admins, secure admin bootstrap, provider verification and suspension workflows.
- Add appointment create/update APIs with participant checks; clinical note/diagnosis/prescription write endpoints with verified-provider and consent checks.
- Use least-privilege database credentials, TLS, backups, restore tests, retention/deletion policies, monitoring and alerting.
- Review applicable Indian data protection and health-data requirements, consent language, retention, incident response and organizational policies with qualified counsel/security professionals.
- Add automated authorization tests for cross-patient access, expired/revoked consent, role escalation, IDOR, and audit-log integrity.

## Deployment
Deploy to Vercel (Next.js) and connect a managed PostgreSQL database (for example Supabase PostgreSQL or another managed provider). Configure `DATABASE_URL` and `SESSION_SECRET` in encrypted deployment environment variables for Production, Preview and Development as appropriate. Configure private object storage before enabling uploads. Run `npm run db:push` in a controlled migration step, then verify registration/login, authorization, consent expiry/revocation, and audit events.

Never commit `.env.local` or secrets.
