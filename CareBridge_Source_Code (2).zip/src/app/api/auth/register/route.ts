import { NextRequest, NextResponse } from "next/server";
import bcrypt from "bcryptjs";
import { z } from "zod";
import { db } from "@/lib/db";
import { users, patientProfiles, providerProfiles } from "@/lib/schema";
import { eq } from "drizzle-orm";

const inputSchema = z.object({
  email: z.email().max(320), password: z.string().min(12).max(128),
  role: z.enum(["patient","doctor","hospital"]), fullName: z.string().min(2).max(160)
});
export async function POST(req: NextRequest) {
  try {
    const input = inputSchema.parse(await req.json());
    const email = input.email.trim().toLowerCase();
    const existing = await db.select({ id: users.id }).from(users).where(eq(users.email, email)).limit(1);
    if (existing.length) return NextResponse.json({ error: "An account with this email already exists." }, { status: 409 });
    const passwordHash = await bcrypt.hash(input.password, 12);
    const created = await db.transaction(async tx => {
      const [user] = await tx.insert(users).values({ email, passwordHash, role: input.role, status: "pending" }).returning({ id: users.id });
      if (input.role === "patient") await tx.insert(patientProfiles).values({ userId: user.id, fullName: input.fullName });
      else await tx.insert(providerProfiles).values({ userId: user.id, displayName: input.fullName, verificationStatus: "pending" });
      return user;
    });
    return NextResponse.json({ ok: true, message: input.role === "patient" ? "Account created. An administrator must activate it before login." : "Account submitted for verification." , userId: created.id }, { status: 201 });
  } catch (e) {
    if (e instanceof z.ZodError) return NextResponse.json({ error: "Please check the submitted fields." }, { status: 400 });
    return NextResponse.json({ error: "Registration is temporarily unavailable. Check server configuration." }, { status: 500 });
  }
}