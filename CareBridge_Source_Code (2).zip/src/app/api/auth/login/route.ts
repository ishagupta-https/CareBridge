import { NextRequest, NextResponse } from "next/server";
import bcrypt from "bcryptjs";
import { z } from "zod";
import { db } from "@/lib/db";
import { users } from "@/lib/schema";
import { eq } from "drizzle-orm";
import { setSession } from "@/lib/session";
import { audit } from "@/lib/audit";

const schema = z.object({ email: z.email(), password: z.string().min(1).max(128) });
export async function POST(req: NextRequest) {
  let email = "";
  try {
    const data = schema.parse(await req.json());
    email = data.email.trim().toLowerCase();
    const [user] = await db.select().from(users).where(eq(users.email, email)).limit(1);
    const ok = user ? await bcrypt.compare(data.password, user.passwordHash) : false;
    if (!user || !ok || user.status !== "active") {
      if (user) await audit({ actorId: user.id, action: "login", resourceType: "session", outcome: "denied", ip: req.headers.get("x-forwarded-for") });
      return NextResponse.json({ error: "Unable to sign in. Check credentials or account activation status." }, { status: 401 });
    }
    await setSession(user.id);
    await audit({ actorId: user.id, action: "login", resourceType: "session", outcome: "success", ip: req.headers.get("x-forwarded-for") });
    return NextResponse.json({ ok: true, role: user.role });
  } catch {
    return NextResponse.json({ error: "Login service is unavailable. Verify server configuration." }, { status: 500 });
  }
}