import { NextResponse } from "next/server";
import { desc } from "drizzle-orm";
import { db } from "@/lib/db";
import { accessAuditLogs } from "@/lib/schema";
import { requireRole } from "@/lib/session";
export async function GET() {
  const user = await requireRole(["admin"]);
  if (!user) return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  const logs = await db.select({
    id: accessAuditLogs.id, actorId: accessAuditLogs.actorId, patientId: accessAuditLogs.patientId,
    action: accessAuditLogs.action, resourceType: accessAuditLogs.resourceType,
    resourceId: accessAuditLogs.resourceId, outcome: accessAuditLogs.outcome, createdAt: accessAuditLogs.createdAt
  }).from(accessAuditLogs).orderBy(desc(accessAuditLogs.createdAt)).limit(200);
  return NextResponse.json({ logs });
}