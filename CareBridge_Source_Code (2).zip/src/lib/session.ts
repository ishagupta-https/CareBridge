import { createHmac, timingSafeEqual } from "node:crypto";
import { cookies } from "next/headers";
import { db } from "./db";
import { users } from "./schema";
import { eq } from "drizzle-orm";

const COOKIE = "carebridge_session";
function secret() {
  const s = process.env.SESSION_SECRET;
  if (!s || s.length < 32) throw new Error("SESSION_SECRET must be configured with at least 32 characters.");
  return s;
}
function sign(value: string) { return createHmac("sha256", secret()).update(value).digest("base64url"); }
export function makeSession(userId: string) {
  const payload = Buffer.from(JSON.stringify({ sub: userId, exp: Date.now() + 1000 * 60 * 60 * 8 })).toString("base64url");
  return `${payload}.${sign(payload)}`;
}
export async function setSession(userId: string) {
  const jar = await cookies();
  jar.set(COOKIE, makeSession(userId), { httpOnly: true, secure: process.env.NODE_ENV === "production", sameSite: "lax", path: "/", maxAge: 60 * 60 * 8 });
}
export async function clearSession() {
  const jar = await cookies();
  jar.set(COOKIE, "", { httpOnly: true, secure: process.env.NODE_ENV === "production", sameSite: "lax", path: "/", maxAge: 0 });
}
export async function currentUser() {
  const token = (await cookies()).get(COOKIE)?.value;
  if (!token) return null;
  const [payload, signature, extra] = token.split(".");
  if (!payload || !signature || extra) return null;
  const expected = sign(payload);
  const a = Buffer.from(signature), b = Buffer.from(expected);
  if (a.length !== b.length || !timingSafeEqual(a, b)) return null;
  try {
    const parsed = JSON.parse(Buffer.from(payload, "base64url").toString()) as { sub: string; exp: number };
    if (!parsed.sub || parsed.exp < Date.now()) return null;
    const [user] = await db.select({ id: users.id, email: users.email, role: users.role, status: users.status }).from(users).where(eq(users.id, parsed.sub)).limit(1);
    if (!user || user.status !== "active") return null;
    return user;
  } catch { return null; }
}
export async function requireRole(roles: Array<"patient"|"doctor"|"hospital"|"admin">) {
  const user = await currentUser();
  if (!user || !roles.includes(user.role)) return null;
  return user;
}