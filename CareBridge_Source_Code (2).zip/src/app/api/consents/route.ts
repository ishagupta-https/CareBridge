import { NextRequest, NextResponse } from "next/server";
import { and, desc, eq } from "drizzle-orm";
import { z } from "zod";
import { db } from "@/lib/db";
import { consents, users } from "@/lib/schema";
import { currentUser } from "@/lib/session";
import { audit } from "@/lib/audit";

const grantSchema = z.object({
  providerId: z.uuid(), documentIds: z.array(z.uuid()).max(100).default([]),
  recordCategories: z.array(z.string().max(40)).max(20).default([]),
  purpose: z.string().min(3).max(300), expiresAt: z.iso.datetime()
});
export async function GET() {
  const user = await currentUser();
  if (!user) return NextResponse.json({ error: "Unauthenticated" }, { status: 401 });
  const where = user.role === "patient" ? eq(consents.patientId, user.id) : eq(consents.providerId, user.id);
  const rows = await db.select({
    id: consents.id, patientId: consents.patientId, providerId: consents.providerId,
    documentIds: consents.documentIds, recordCategories: consents.recordCategories,
    purpose: consents.purpose, grantedAt: consents.grantedAt, expiresAt: consents.expiresAt, revokedAt: consents.revokedAt
  }).from(consents).where(where).orderBy(desc(consents.createdAt));
  return NextResponse.json({ consents: rows });
}
export async function POST(req: NextRequest) {
  const user = await currentUser();
  if (!user) return NextResponse.json({ error: "Unauthenticated" }, { status: 401 });
  if (user.role !== "patient") return NextResponse.json({ error: "Only the patient can grant consent." }, { status: 403 });
  try {
    const data = grantSchema.parse(await req.json());
    const [provider] = await db.select({ id: users.id, role: users.role, status: users.status }).from(users).where(eq(users.id, data.providerId)).limit(1);
    if (!provider || !["doctor","hospital"].includes(provider.role) || provider.status !== "active") return NextResponse.json({ error: "Provider is not active and verified." }, { status: 400 });
    const expiresAt = new Date(data.expiresAt);
    if (expiresAt <= new Date() || expiresAt > new Date(Date.now() + 90 * 86400000)) return NextResponse.json({ error: "Consent expiry must be within the next 90 days." }, { status: 400 });
    const [created] = await db.insert(consents).values({
      patientId: user.id, providerId: data.providerId, documentIds: data.documentIds,
      recordCategories: data.recordCategories, purpose: data.purpose, expiresAt
    }).returning({ id: consents.id });
    await audit({ actorId: user.id, patientId: user.id, action: "grant_consent", resourceType: "consent", resourceId: created.id, outcome: "success" });
    return NextResponse.json({ ok: true, id: created.id }, { status: 201 });
  } catch (e) {
    if (e instanceof z.ZodError) return NextResponse.json({ error: "Invalid consent details." }, { status: 400 });
    return NextResponse.json({ error: "Consent could not be saved." }, { status: 500 });
  }
}