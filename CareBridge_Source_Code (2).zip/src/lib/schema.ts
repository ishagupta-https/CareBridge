import { pgTable, pgEnum, uuid, varchar, text, timestamp, date, boolean, integer, jsonb, index, uniqueIndex } from "drizzle-orm/pg-core";

export const roleEnum = pgEnum("user_role", ["patient","doctor","hospital","admin"]);
export const accountStatusEnum = pgEnum("account_status", ["pending","active","suspended"]);
export const appointmentStatusEnum = pgEnum("appointment_status", ["requested","confirmed","completed","cancelled"]);
export const documentTypeEnum = pgEnum("document_type", ["consultation","diagnosis","lab_report","prescription","vaccination","allergy","treatment","other"]);

export const users = pgTable("users", {
  id: uuid("id").defaultRandom().primaryKey(),
  email: varchar("email", { length: 320 }).notNull(),
  passwordHash: text("password_hash").notNull(),
  role: roleEnum("role").notNull(),
  status: accountStatusEnum("status").notNull().default("pending"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow()
}, t => [uniqueIndex("users_email_unique").on(t.email), index("users_role_idx").on(t.role)]);

export const patientProfiles = pgTable("patient_profiles", {
  userId: uuid("user_id").primaryKey().references(() => users.id, { onDelete: "cascade" }),
  fullName: varchar("full_name", { length: 160 }).notNull(),
  dateOfBirth: date("date_of_birth"),
  phone: varchar("phone", { length: 32 }),
  bloodGroup: varchar("blood_group", { length: 8 }),
  emergencyContact: varchar("emergency_contact", { length: 160 }),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow()
});

export const providerProfiles = pgTable("provider_profiles", {
  userId: uuid("user_id").primaryKey().references(() => users.id, { onDelete: "cascade" }),
  displayName: varchar("display_name", { length: 180 }).notNull(),
  registrationNumber: varchar("registration_number", { length: 100 }),
  hospitalName: varchar("hospital_name", { length: 180 }),
  specialty: varchar("specialty", { length: 120 }),
  verificationStatus: varchar("verification_status", { length: 24 }).notNull().default("pending"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow()
});

export const appointments = pgTable("appointments", {
  id: uuid("id").defaultRandom().primaryKey(),
  patientId: uuid("patient_id").notNull().references(() => users.id),
  providerId: uuid("provider_id").notNull().references(() => users.id),
  startsAt: timestamp("starts_at", { withTimezone: true }).notNull(),
  reason: varchar("reason", { length: 500 }),
  status: appointmentStatusEnum("status").notNull().default("requested"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow()
}, t => [index("appointments_patient_idx").on(t.patientId), index("appointments_provider_idx").on(t.providerId)]);

export const encounters = pgTable("encounters", {
  id: uuid("id").defaultRandom().primaryKey(),
  patientId: uuid("patient_id").notNull().references(() => users.id),
  providerId: uuid("provider_id").notNull().references(() => users.id),
  appointmentId: uuid("appointment_id").references(() => appointments.id),
  occurredAt: timestamp("occurred_at", { withTimezone: true }).notNull().defaultNow(),
  summary: text("summary").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow()
}, t => [index("encounters_patient_date_idx").on(t.patientId, t.occurredAt)]);

export const diagnoses = pgTable("diagnoses", {
  id: uuid("id").defaultRandom().primaryKey(),
  encounterId: uuid("encounter_id").notNull().references(() => encounters.id, { onDelete: "cascade" }),
  codeSystem: varchar("code_system", { length: 30 }),
  code: varchar("code", { length: 40 }),
  description: varchar("description", { length: 500 }).notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow()
});

export const observations = pgTable("observations", {
  id: uuid("id").defaultRandom().primaryKey(),
  patientId: uuid("patient_id").notNull().references(() => users.id),
  encounterId: uuid("encounter_id").references(() => encounters.id),
  kind: varchar("kind", { length: 80 }).notNull(),
  value: varchar("value", { length: 120 }).notNull(),
  unit: varchar("unit", { length: 32 }),
  observedAt: timestamp("observed_at", { withTimezone: true }).notNull().defaultNow()
}, t => [index("observations_patient_idx").on(t.patientId, t.observedAt)]);

export const medications = pgTable("medications", {
  id: uuid("id").defaultRandom().primaryKey(),
  patientId: uuid("patient_id").notNull().references(() => users.id),
  name: varchar("name", { length: 180 }).notNull(),
  dosage: varchar("dosage", { length: 120 }),
  instructions: text("instructions"),
  active: boolean("active").notNull().default(true),
  startedAt: date("started_at"),
  endedAt: date("ended_at")
}, t => [index("medications_patient_idx").on(t.patientId, t.active)]);

export const prescriptions = pgTable("prescriptions", {
  id: uuid("id").defaultRandom().primaryKey(),
  encounterId: uuid("encounter_id").notNull().references(() => encounters.id, { onDelete: "cascade" }),
  medicationId: uuid("medication_id").references(() => medications.id),
  providerId: uuid("provider_id").notNull().references(() => users.id),
  notes: text("notes"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow()
});

export const medicalDocuments = pgTable("medical_documents", {
  id: uuid("id").defaultRandom().primaryKey(),
  patientId: uuid("patient_id").notNull().references(() => users.id),
  uploadedBy: uuid("uploaded_by").notNull().references(() => users.id),
  encounterId: uuid("encounter_id").references(() => encounters.id),
  type: documentTypeEnum("type").notNull().default("other"),
  title: varchar("title", { length: 220 }).notNull(),
  storageKey: text("storage_key").notNull(),
  mimeType: varchar("mime_type", { length: 100 }).notNull(),
  sizeBytes: integer("size_bytes").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow()
}, t => [index("medical_documents_patient_idx").on(t.patientId, t.createdAt)]);

export const consents = pgTable("consents", {
  id: uuid("id").defaultRandom().primaryKey(),
  patientId: uuid("patient_id").notNull().references(() => users.id),
  providerId: uuid("provider_id").notNull().references(() => users.id),
  documentIds: jsonb("document_ids").$type<string[]>().notNull().default([]),
  recordCategories: jsonb("record_categories").$type<string[]>().notNull().default([]),
  purpose: varchar("purpose", { length: 300 }).notNull(),
  grantedAt: timestamp("granted_at", { withTimezone: true }).notNull().defaultNow(),
  expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
  revokedAt: timestamp("revoked_at", { withTimezone: true }),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow()
}, t => [index("consents_patient_idx").on(t.patientId), index("consents_provider_idx").on(t.providerId)]);

export const accessAuditLogs = pgTable("access_audit_logs", {
  id: uuid("id").defaultRandom().primaryKey(),
  actorId: uuid("actor_id").references(() => users.id),
  patientId: uuid("patient_id").references(() => users.id),
  action: varchar("action", { length: 100 }).notNull(),
  resourceType: varchar("resource_type", { length: 100 }).notNull(),
  resourceId: varchar("resource_id", { length: 180 }),
  outcome: varchar("outcome", { length: 24 }).notNull(),
  ipHash: varchar("ip_hash", { length: 128 }),
  metadata: jsonb("metadata").$type<Record<string, unknown>>().notNull().default({}),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow()
}, t => [index("audit_patient_date_idx").on(t.patientId, t.createdAt), index("audit_actor_date_idx").on(t.actorId, t.createdAt)]);

export const notifications = pgTable("notifications", {
  id: uuid("id").defaultRandom().primaryKey(),
  userId: uuid("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  title: varchar("title", { length: 180 }).notNull(),
  body: text("body").notNull(),
  readAt: timestamp("read_at", { withTimezone: true }),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow()
}, t => [index("notifications_user_idx").on(t.userId, t.createdAt)]);
