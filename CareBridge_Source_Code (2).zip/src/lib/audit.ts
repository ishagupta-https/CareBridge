import { createHash } from "node:crypto";
import { db } from "./db";
import { accessAuditLogs } from "./schema";
export async function audit(input: {
  actorId?: string | null; patientId?: string | null; action: string;
  resourceType: string; resourceId?: string | null; outcome: "allowed"|"denied"|"success"|"failure";
  ip?: string | null; metadata?: Record<string, unknown>;
}) {
  await db.insert(accessAuditLogs).values({
    actorId: input.actorId ?? null, patientId: input.patientId ?? null, action: input.action,
    resourceType: input.resourceType, resourceId: input.resourceId ?? null, outcome: input.outcome,
    ipHash: input.ip ? createHash("sha256").update(input.ip).digest("hex") : null,
    metadata: input.metadata ?? {}
  });
}