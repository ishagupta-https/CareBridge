import { NextResponse } from "next/server";
import { clearSession, currentUser } from "@/lib/session";
import { audit } from "@/lib/audit";
export async function POST() {
  const user = await currentUser();
  if (user) await audit({ actorId: user.id, action: "logout", resourceType: "session", outcome: "success" });
  await clearSession();
  return NextResponse.json({ ok: true });
}