 "use client";
import { useRouter } from "next/navigation";
import { LogOut } from "lucide-react";
export default function LogoutButton(){const router=useRouter();return <button aria-label="Sign out" title="Sign out" onClick={async()=>{await fetch("/api/auth/logout",{method:"POST"});router.push("/login");router.refresh();}} className="rounded-lg p-2 text-[#718278] hover:bg-[#eef6f0] hover:text-[#104C39]"><LogOut size={18}/></button>}