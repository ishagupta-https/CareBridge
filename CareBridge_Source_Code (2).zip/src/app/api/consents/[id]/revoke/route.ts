import { NextResponse } from "next/server";
import { and, eq, isNull } from "drizzle-orm";
import { db } from "@/lib/db";
import { consents } from "@/lib/schema";
import { currentUser } from "@/lib/session";
import { audit } from "@/lib/audit";
export async function POST(_req: Request, context: { params: Promise<{ id: string }> }) {
  const user = await currentUser();
  if (!user) return NextResponse.json({ error: "Unauthenticated" }, { status: 401 });
  if (user.role !== "patient") return NextResponse.json({ error: "Only the patient can revoke consent." }, { status: 403 });
  const { id } = await context.params;
  const [revoked] = await db.update(consents).set({ revokedAt: new Date() }).where(and(
    eq(consents.id, id), eq(consents.patientId, user.id), isNull(consents.revokedAt)
  )).returning({ id: consents.id });
  if (!revoked) return NextResponse.json({ error: "Consent not found or already revoked." }, { status: 404 });
  await audit({ actorId: user.id, patientId: user.id, action: "revoke_consent", resourceType: "consent", resourceId: id, outcome: "success" });
  return NextResponse.json({ ok: true });
}